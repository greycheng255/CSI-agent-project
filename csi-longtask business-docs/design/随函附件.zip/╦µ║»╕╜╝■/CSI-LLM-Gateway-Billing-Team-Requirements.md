# LLM 网关与计费团队 — 对接能力需求清单（Console 侧提给网关团队）

> **文档目的**：本文是 CSI Agent Owner Console（下称 Console）向 LLM 模型网关与计费团队（下称网关团队）提出的**能力提供清单**——逐项说明网关联调需要对方提供什么、做到什么程度、以什么形态交付，使双方各自清楚自己的工作面。
> **契约基线**：本文全部条目源自双方已裁决的契约（《CSI-Agent-Owner-Console-Integration-Guide》§3.7 + 技术方案 DR-12：TS §17.2/§17.3.5/§17.4/§2.4/附录 B.3/B.6 + PRD §4.3/§4.4/§4.6），不是新需求。裁决点不再重议；实现细节（URL 路径、字段命名、认证机制选型）由网关团队定案后回写本文 §6。
> **修订注记（2026-08-28 定稿版）**：按 Owner 当日裁决补充——org 语义定案（账号级；**org 分配/解析归平台统一账户体系【基础设施团队，Integration Guide §4.2】，网关以 org_id 为不透明计费主体键**；免费额度激活 E6 由 Console 入驻编排触发）；K2 增 run 级计量关联键；ChatStream 计量收尾帧硬性要求；新增 L3 模型目录端点与 §1.4 调用频率画像；D6 key 生命周期测试数据与场景矩阵补全。
> **Console 侧实施载体**：联调 task `08-28-csi-gateway-integration`（Phase 1 第一项 = 以本文逐项核对出的"网关契约核对报告"）。

---

## 0. 双方职责分界（一页速览）

![三块分工与 daemon 本地代理架构](assets/csi-gateway-integration-arch.svg)

> 上图：①三块分工（网关团队 / Console / 双方对接面五项）②daemon 本地代理调用链（key 的流转与安全边界）。

| 网关团队提供 | Console 侧负责 |
|---|---|
| 统一 LLM 网关服务端（模型目录 + 统一调用入口 + 计量） | `GatewayProvider`（LLMProviderPort CSIAdapter，网关客户端） |
| 订阅套餐/权益/额度/账单服务端（商业化面，含公测免费额度激活端点 E6） | `EntitlementPort` CSIAdapter（权益校验客户端，接口骨架已就绪）+ Console 侧 org_id 消费与入驻编排 |
| workspace 级 LLM key 签发/吊销/轮换服务（云端 Runtime 凭证，K1-K4） | Runtime 接入链路（daemon 本地代理持 key 调网关） |
| 错误语义按 §2 对齐（4xx 业务态 + 错误码族） | 错误码映射与 Pre-dispatch 拦截（`PREDISPATCH_*`） |
| 计量数据与对账 API（workspace_id 归集） | 对账接线（周期性比对 + 偏差告警） |
| 联调沙箱环境 + 测试数据 + 错误场景构造 | 联调执行、122 K8s 实证、证据归档 |
| 套餐运营参数（免费额度数值/有效期/升降级规则） | `/settings/billing` 展示位接入 |

**org 归属边界（跨团队）**：账号入驻默认分配 org（owner 角色）与账号→org 解析归平台统一账户体系（基础设施团队，Integration Guide §4.2）；网关与 Console 均为 org_id 消费方（前提注记见 §1.1）。

**两条资金流边界（不要混建）**：雇主→平台→工作室的项目款结算属 Marketplace/SettlementPort 域（不在本清单）；Agent Owner→平台的 LLM 用量与订阅费属本清单域。Console 内部 `compute_cost_used` 项目预算风控与平台商业化计费是两个独立维度：套餐额度管"能不能调"，项目预算管"该不该花"。

---

## 1. 接口面（网关服务端需提供，E/L/K 三族 13 项：E1-E6 / L1-L3 / K1-K4）

> 形态约定：HTTP/JSON（OpenAI 兼容或自定义均可，由网关团队定）；统一信封与错误结构建议与 Console 的 `ChatResponse`/`Usage`/`Cost` 结构对齐（见 §1.2）；服务间认证见 §3.1。

### 1.1 Entitlement 权益接口族（对应 Console `EntitlementPort` 五方法 + E6 免费额度激活，只读+校验）

Console 侧客户端接口骨架已就绪（`server/internal/ports/entitlement_port.go`，M4-D7 落地——方法面与错误语义稳定）。**注意：骨架是 M4 最小面，结构体/签名将随联调 task 按下表语义扩展**（如 GetUsage 请求键从过渡 org 键改为 workspace 归集键 + 游标/run 级明细、GetPlan 周期字段、GetQuota 总量/已用字段）；**网关侧请按下表完整语义提供服务端，勿按骨架当前最小字段裁剪**。E6 为 Port 之外的入驻编排通道（公测免费额度激活，幂等）。

**org_id 前提（跨团队，非本清单契约面）**：org 分配/解析归平台统一账户体系（基础设施团队——账号注册默认分配绑定 org【owner 角色】；Console 经 SSO 登录态 claim 或解析 API 取得并本地持久化，详见 Integration Guide §4.2）。网关以 org_id 为**不透明计费主体键**消费（E1-E3/E6/K1 入参，运行时零身份依赖）；**联调期身份面未就绪时，以双方约定的 org_id 测试值直测沙箱**（E 族接口不依赖身份服务，联调不被身份面阻塞；生产接入前回收该替代，测试值约定落 §6 回写区）。

| # | 接口 | 请求 | 响应（关键字段） | Console 消费点 |
|---|---|---|---|---|
| E1 | **GetPlan** 套餐查询 | `org_id` | 套餐标识、名称、订阅周期（起止/重置时间）、状态（active/expired/cancelled） | 创建 RuntimeInstance 前校验、 billing 页展示 |
| E2 | **GetCatalog** 权益目录 | `org_id`（可选 kind 过滤） | 可用模型目录（模型 ID/规格/是否旗舰）、RuntimeProfile 规格范围、RuntimeInstance 数上限 | `agents.provider` 可选值下发、创建页可选列表 |
| E3 | **GetQuota** 额度查询 | `org_id` | LLM 额度总量/已用/剩余、周期重置时间、免费额度标记与有效期 | Pre-dispatch 额度校验（余额不足→拒绝派发）、额度预警 |
| E4 | **GetUsage** 用量账单 | `workspace_id` + 时间窗（支持增量游标） | 用量明细/汇总（token 输入/输出/总计、成本、模型、run 级 `agent_run_id` 关联键） | 对账（§4.2）、用量拆解展示 |
| E5 | **Capabilities** 能力声明 | — | 服务版本、支持的特性集（如按量溢价是否开放） | 接入自检 |
| E6 | **ActivateFreeQuota** 公测免费额度激活 | `org_id`（幂等：重复调用返回当前状态，不重复发放） | 发放结果、额度数值、有效期起止 | Console 在 agent owner 入驻流程（首次进入 Console）调用——"入驻即赠"触发点（统一账户体系不区分雇主/owner 账号，触发不能挂注册流程；有效期时钟锚定入驻时刻） |
| E7 | **GetLLMConfig** BYOK 凭证数据面（2026-09-02 M 侧新增并请 Console 登记确认；**契约层注记：此端点非本文原契约面，属 BYOK 公测口径新增**） | `org_id`（路径参数；HMAC 服务级） | `{org_id, base_url, api_key}` | BYOK 公测期凭证下发通道之一（服务级批量；与 runtime-env JWT 通道并行）；公测挂起面（E6/K1-K4）之外的保留面；TS §17.3.5/B.6 已补登记（2026-09-02）；5 处 BYOK 冲突处置 Owner 裁决前仅登记不接入 |

**业务规则对齐（PRD §4.6 已裁决 + 2026-08-28 Owner 补充裁决 org 语义）**：订阅主体 = **账号级 Org**——账号入驻时平台默认分配生成并绑定一个 org（该账号在此 org 为 owner 权限），一个账号下的多个 Workspace 共享该 org 的套餐与额度；权益校验键 = `org_id`（Console 经平台统一账户体系——SSO 登录态 claim 或解析 API——取得并本地持久化），计量归集键 = `workspace_id`（TenantID）；演进方向（公测不建，仅预留语义）= 账号可被邀请加入他人 org（member 权限）并多 org 切换。公测免费额度 = **随入驻账号（org）发放**、入驻即赠（触发 = Console 入驻编排幂等调 E6）、有有效期、不可转让、**数值与有效期为平台运营参数配置化**（不写死契约）；耗尽处置 = 公测硬断（4xx + urgent 通知），正式版支持按量溢价；升降级 = 升级即时生效（差价折算）、降级下周期生效。

### 1.2 LLM 代理调用接口（对应 `LLMProviderPort`）

| # | 接口 | 说明 |
|---|---|---|
| L1 | **Chat** / **ChatStream** | 统一聊天调用入口（多厂商/多规格路由在网关服务端）；请求携带 workspace 归属（见 §3.2 令牌）+ 模型 ID + run 关联标识（见 K2） |
| L2 | **Embed** | 向量化（若公测目录含） |
| L3 | **模型目录/能力声明** | 模型目录端点（OpenAI 兼容 `/v1/models` 形态即可）+ 能力声明（流式/工具调用/视觉）——对齐 `LLMProviderPort.Capabilities` 语义 |

**响应计量结构必须对齐**（Console 既有 `ChatResponse` 契约）：`Usage`（prompt/completion/total tokens）+ `Cost`（按定价表折算，含币种/单位——**币种与计价精度为 §6 定案项**，Console 侧落账口径为整数分 `cost_cents`）+ `Model`（实际响应的模型版本）+ `TenantID`（回显 workspace_id 归集键）。**计量权威在网关**：Console 侧落账（`agent_runs.token_usage_*`/`cost_cents`）只是网关数据的副本，用于项目成本风控与展示，不作计费依据。

**两条硬性计量要求**：

1. **ChatStream 计量收尾帧**：流式调用必须在最终帧携带完整 `Usage`/`Cost`/`Model`（OpenAI 兼容形态即 `stream_options.include_usage` 必须开启）——Console 的 `agent_runs` 落账依赖 daemon 从流中取得计量，缺失即计量链路断。
2. **模型 ID 命名空间一致性**：E2 目录下发的模型 ID 必须可直接作为 L1 的 `model` 参数值（同一命名空间；Console `agents.provider` 存储同一 ID）。

### 1.3 云端托管 Runtime 的 LLM 调用通道（daemon 本地代理模型，公测已裁决）

**安全基线（Integration Guide §3.7.2，Owner 2026-08-28 终裁公测形态）**：平台**永不存储、永不下发** Agent Owner 的上游模型厂商 API key；云端托管 Runtime 的 LLM 调用走 **daemon 内本地代理**——

```
agent CLI（AI 生成代码，最不可信组件）
  │  LLM 请求只指向 localhost endpoint（daemon 内本地 LLM 代理）
  ▼
daemon 本地 LLM 代理（key 内存态缓存，不落盘、不注入 CLI 子进程 env）
  │  转发（带网关签发的 workspace 级 LLM key）
  ▼
平台 LLM 网关（key → workspace 归属计量；上游厂商 key 永不出网关）
```

**模型选型理由（相对两个备选）**：①不把长期 key 注入 CLI 子进程 env——CLI 执行 AI 生成代码，prompt 注入即可读取子进程 env，"凭证不进 CLI 进程"优先于"凭证短命"；②不经 Console API 代理全量 LLM 流量——Console 不承载 LLM 带宽与可用性单点；③CLI 侧零新机制——provider base_url 指向 localhost，完全复用 CLI 既有自定义 provider 配置面；④演进不烧桥——未来若收紧为短期令牌，只换 daemon 代理背后的凭证获取逻辑，CLI 接口零改动。

需要网关团队提供：

| # | 能力 | 说明 |
|---|---|---|
| K1 | **workspace 级 LLM key 签发** | 按下发对象签发（绑定 workspace_id 计量归集）；**签发请求携带 org_id + workspace_id，网关建立并记录 workspace→org 绑定**（账号级额度共享的执行基础）；形态 = 网关既有 API key 体系，非新令牌机制 |
| K2 | **key 校验与计量绑定** | L1/L2 调用入口接受该 key；key → TenantID（workspace_id）归集；**调用入口支持携带 run 关联标识（如 header，值为 Console `agent_run_id`），计量明细按 run 归集**——E4 run 级明细与滥用检测（本节末表）的前提 |
| K3 | **key 吊销/轮换** | 支持按 workspace 吊销（Runtime 销毁/权益变更/滥用检测触发时）；支持轮换（旧 key 立即失效） |
| K4 | **CIDR 来源限制**（建议公测即配） | key 限定平台内网 CIDR 调用——堵死"取出 key 在外部工具直呼网关"的朴素路径；网关侧一条配置，Console 侧零改动。**沙箱 CIDR 白名单需含 Console dev 环境出口 IP**（否则 §5 阶段 1 直测被拒） |

Console 侧负责：

- **org 映射落地**：经平台统一账户体系（基础设施团队——SSO 登录态 claim 或解析 API）取得账号→org_id 并本地持久化；权益校验链路（Pre-dispatch/创建页）传真实 org_id——替换 M4 过渡行为（checker 现以 workspace_id 冒充 org 键，本 task 切换）；
- **入驻编排**：agent owner 首次进入 Console 的入驻流程中幂等调用 E6 激活公测免费额度（统一账户体系不区分雇主/owner 账号，触发点归 Console 入驻编排，不挂注册流程）；
- **daemon 注入 run 标识**：daemon 本地代理转发 L1 时注入当前 `agent_run_id`（daemon 知道当前执行的 run）——K2 run 级计量的数据源；外部偷 key 调用无有效 run 标识，本身即滥用信号；
- **key 下发端点**：骑既有 daemon→Console 认证面（register/heartbeat/claim 同源凭证授权，零新增认证机制；授权口径随联调判例"claim-key 知识即授权"一并定案）——daemon 首次 LLM 请求前获取，内存缓存；
- **401 重取**：网关返 401（key 轮换/吊销后）→ daemon 重新拉取并重试一次；
- **heartbeat 顺带轮换**（增强项）：daemon 挂既有 heartbeat 周期顺带刷新 key（如每 24h），把"长期有效"压成"事实上有界"；
- **销毁吊销**：Runtime 销毁/权益变更时 Console 调 K3。

#### key 滥用缓解（公测姿态：三道栅栏 + 已知残余）

威胁模型承认：owner 在信任边界内（可指示 agent 提取 daemon 内凭证），"防外用"没有纯软件完全解——设计目标是"偷走也不划算"：

| 栅栏 | 成本 | 机制 |
|---|---|---|
| 经济 | 零（已有） | quota 硬断——滥用消耗的是 owner 自己额度，损失有界 |
| 检测 | 零（语义新增） | **对账闭环（§4.2）天然是滥用检测器**：网关按 workspace 计量 vs Console `agent_runs` 落账比对——外部使用的调用量在网关侧有、Console 侧无 run 记录，差值直接暴露（K2 run 标识使比对精确到 run 级：无有效 run 标识的 key 调用本身即滥用信号）；触发即告警 + 轮换该 workspace key（K3）+ 通知 owner，惯犯升级处置 |
| 网络摩擦 | 网关一条配置 | K4 CIDR 限制 |

**已知残余（公测显式接受）**：owner 指示 agent 在 runtime 内起反向隧道（frp/cloudflare tunnel 等）将 daemon localhost 代理暴露公网——流量从 pod 内出、带 key、烧自己额度。**闭合手段 = NetworkPolicy 出向白名单**（公测已延期，Owner 2026-08-28 裁决；其复位即闭合此向量——这是延期决策的已知代价之一，已在 Console 侧 task prd 登记）。

### 1.4 调用频率画像与延迟预算（网关容量设计输入）

| 接口 | 调用时机 | 频率 / 延迟要求 |
|---|---|---|
| E6 ActivateFreeQuota | agent owner 入驻（首次进入 Console） | 一次性；幂等 |
| E1 GetPlan | 创建 RuntimeInstance 前、billing 页 | 低频 |
| E2 GetCatalog | 创建页 / `agents.provider` 可选值下发 | Console 侧缓存 ≤5min（新鲜度分钟级即可） |
| E3 GetQuota | **每次 pre-dispatch（派发热路径，同步调用）** | 高频；**建议 p99 < 500ms**；Console fail-closed（超时/故障 = 拒绝派发 E_SYSTEM）——网关可用性直接 gating 派发 |
| E4 GetUsage | 每小时增量 + 每日全量对账拉取 | 批量；可容忍秒级 |
| L1/L2/L3 | run 执行期 LLM 流量 + 目录拉取 | 随业务流量 |
| K1/K3 | Runtime 启动 / 销毁 / 轮换 | 低频 |

---

## 2. 错误语义（必须对齐，已裁决）

- **业务拒绝 = 4xx 业务态，不可重试**；不得落入 `UPSTREAM_*` / `INTERNAL_*` 可重试族。网关自身故障/上游模型厂商故障才属 5xx 可重试。
- **错误码族对齐**（TS 附录 B.6 / B.3）：

| 网关返回场景 | 对齐错误码 | Console 侧处置 |
|---|---|---|
| 订阅主体无有效套餐 | `ENTITLEMENT_PLAN_NOT_FOUND` | 引导订阅/激活公测免费额度 |
| 云端 RuntimeInstance 数超套餐上限 | `ENTITLEMENT_LIMIT_REACHED` | 释放实例或升级套餐 |
| 所选模型/Profile 不在套餐目录 | `ENTITLEMENT_CATALOG_DENIED` → Pre-dispatch 映射 `PREDISPATCH_MODEL_NOT_ENTITLED` | 换目录内选项或升级 |
| LLM 额度耗尽 | `ENTITLEMENT_QUOTA_EXHAUSTED` → Pre-dispatch 映射 `PREDISPATCH_LLM_QUOTA_EXHAUSTED`（已落码） | 充值/升级；urgent 通知 Owner |

- 响应体错误结构：`{code, message, retryable: false, details?}`——Console 侧按 code 做映射表（映射契约是联调核对项）。

---

## 3. 认证与安全

| # | 项 | 需网关团队定案/提供 |
|---|---|---|
| 3.1 | **Console↔网关服务间认证** | 机制选型（HMAC 签名 / mTLS / OIDC client credentials）+ 凭证分发方式（线下安全渠道）——Console 调用 E1-E6/K1/K3 用 |
| 3.2 | **workspace 级 LLM key 体系** | key 格式/签发与轮换端点/CIDR 限制配置（K1-K4）——公测采用网关既有 API key 体系，非新令牌机制（短期令牌为未来演进项） |
| 3.3 | **凭证边界确认** | 上游模型厂商 key 由网关持有，永不出网关边界；owner 自定义 provider key 公测不接入（云端托管强制走网关） |
| 3.4 | **传输与可达** | TLS；沙箱与生产 endpoint 分离；Console dev 环境与 122 K8s 集群到网关沙箱的网络连通（出向白名单如需开通，提供 IP/域名清单给双方运维） |

---

## 4. 数据与联调环境

### 4.1 测试数据（沙箱预置）

| # | 数据 | 用途 |
|---|---|---|
| D1 | 测试 Org（≥2：一个含有效套餐，一个无套餐；org_id 用双方约定测试值——联调无需身份服务在环） | E1 双路径 + `ENTITLEMENT_PLAN_NOT_FOUND` 场景 |
| D2 | 套餐内模型目录（≥2 模型，其一标记套餐外） | E2 目录下发 + `PREDISPATCH_MODEL_NOT_ENTITLED` 场景 |
| D3 | 低额度套餐（如 1000 token） | 快速触发 `QUOTA_EXHAUSTED`（E3/Pre-dispatch 链路） |
| D4 | 免费额度套餐（带有效期，经 E6 激活发放） | 公测赠送语义验证 + E6 幂等（重复激活不重复发放） |
| D5 | 可真实调用的低成本模型（如 lite 档） | L1 真实调用链（控制联调成本） |
| D6 | 可吊销/轮换的 workspace key（K1 签发→K3 吊销/轮换完整生命周期） | daemon 401 重取链路 + key 生命周期场景（§5 阶段 3） |

### 4.2 对账口径（已裁决）

- Console 周期性拉取 E4 与本地落账比对：**每小时增量 + 每日全量**；偏差阈值默认 0.5%（可配置；**按 cost 与 token 双口径分别比对，任一超阈即告警**），超阈值 Console 写 watchdog_logs + reminder 通知 Owner。
- E4 需支持**增量游标**（按时间窗或序号续拉）与 run 级 `agent_run_id` 关联键（用量拆解到项目/Agent）。**游标不丢语义**：网关须保证游标推进后的数据完备——计量写入延迟的数据不得因游标已越过而漏记（游标推进前数据已稳定，或支持回看窗口/重叠拉取），否则对账产生系统性假偏差。
- 时间口径：套餐额度按**订阅周期**滚动；Console 内部 `monthly_budget_cents` 按自然月重置（内部风控，独立口径，展示分别标注）。
- **【待网关确认】E4 是否支持 org 级/批量用量查询**：Console 对账扫描覆盖**全部绑定 workspace**（含无活动 workspace——key 疑似外用时，无活动 workspace 恰是信噪比最高的检测场景），当前按 per-workspace 每小时拉取 E4。若网关支持**一次拉取一个 org_id 下全部 workspace 的用量**（或 E4 支持批量 workspace_id 列表入参），Console 侧拉取成本从 O(绑定 workspace 数)/小时降为 O(org 数)/小时，规模化上限彻底解除——请在 §6 回写确认支持形态（org 级端点 / 批量入参 / 仅 per-workspace）。

### 4.3 联调环境清单（请网关团队提供）

1. 沙箱 base URL（E1-E6/L1-L3/K1-K4 同域或分域说明）+ 认证凭证（经安全渠道）
2. 测试数据 D1-D6 预置完成确认
3. 沙箱可用性窗口与变更通知机制（接口变更提前告知）
4. 沙箱数据重置策略：预置数据在联调期间的持久性承诺（如需重置，提前通知）
5. 联系人：契约答疑 + 联调排障各一

---

## 5. 建议联调节奏（双方对齐后可调整）

| 阶段 | 内容 | 出口 |
|---|---|---|
| 0 契约核对 | 双方按本文逐项确认差异（URL/字段/认证/错误结构）——网关团队回写 §6 | 差异清单清零 |
| 1 单接口联调 | E1-E6 + L1-L3 + K1/K3 逐接口调通（Console 用 curl/脚本直测沙箱；K4 沙箱 CIDR 白名单需含 dev 出口 IP，否则直测被拒） | 接口冒烟记录 |
| 2 链路联调 | Pre-dispatch 校验链（额度/目录/实例上限）+ workspace 级 key 下发注入（daemon 内存缓存）+ daemon→网关真实调用一条链 | 链路证据 |
| 3 场景联调 | D1-D6 场景全过——商业错误场景（无套餐/套餐外/额度耗尽/实例超限/免费额度到期）+ key 生命周期场景（K3 吊销/轮换后 L1 返 401 → daemon 重取重试；K4 CIDR 预期外来源被拒） | 场景矩阵记录 |
| 4 对账演练 | 构造用量 → E4 增量/全量比对 → 偏差注入演练 | 对账报告 |
| 5 122 实证 | Console 侧 K8s 环境的端到端实证（runtime 真实调用经网关） | 实证归档 |

> **说明**：云端 Pod 出向 NetworkPolicy 白名单（仅放行网关+Console API+对象存储+DNS）**公测阶段 Console 侧已降级为后续迭代**（Owner 2026-08-28 裁决，非公测重点）——阶段 5 不含 NetworkPolicy 阻断验证，但请网关团队知悉该边界设计仍在路线图内（重启用时另行立项）。

---

## 6. 网关团队回写区（契约核对阶段填写）

| 项 | 网关团队定案 |
|---|---|
| 沙箱/生产 base URL | （待填） |
| 服务间认证机制与凭证分发 | （待填） |
| 接口路径与字段命名（E1-E6/L1-L3/K1-K4 映射表） | （待填） |
| 联调期 org_id 测试值约定（E1-E3/E6/K1 入参；身份面接入前的替代口径） | （待填） |
| 计价币种与精度（Cost 口径；Console 侧落账为整数分） | （待填） |
| E4 拉取形态：org 级/批量查询是否支持（§4.2 待确认项）；E4 增量游标语义（续拉返回全窗聚合 vs 自 cursor 起增量） | （待填） |
| workspace 级 LLM key 签发/轮换/CIDR 配置（K1-K4） | （待填） |
| 错误结构与 code 清单 | （待填） |
| 测试数据预置确认（D1-D6） | （待填） |
| 联调窗口与联系人 | （待填） |
| 差异/偏离记录（对本文任一条目） | （待填，走 drift 流程对齐） |

---

## 附：权威文档索引

- 集成总指南：`docs/design/CSI-Agent-Owner-Console-Integration-Guide.md` §3.7（LLM 网关与计量计费契约面）/ §4.5（网关团队任务分解）
- 技术方案：`docs/design/CSI-Agent-Owner-Console-Technical-Solution.md` §17.2（Port 清单）/ §17.3.5（EntitlementPort 接口）/ §17.3.3（LLMProviderPort）/ §2.4（托管网络边界）/ 附录 B.3/B.6（错误码）
- PRD：§4.3 托管策略 / §4.4 模型选择 / §4.6 订阅套餐与 LLM 额度
- Console 侧联调 task：`.trellis/tasks/08-28-csi-gateway-integration/prd.md`
