# Evidence: 网关计费面全量探针（2026-09-07 11:53-12:15 UTC）

> 目的（Owner 09-07 指令）：不再信函往返，直接冒烟真实端点，用响应签名编出网关面完整可用性地图与缺口清单。
> 方法：13 个探针（12 端点 + 1 个不存在路径作 404 对照），c2m- 凭证 + 同构 HMAC 签名（X-Signature/X-Request-Id），122 宿主容器 `/dev/tcp` 原始 HTTP。探针清单 = 我方 GatewayClient 常量区全部路径（gateway_client.go L90-105）。

## 结果矩阵

| 端点 | 路径 | 内网 172.17.0.14:4001（marketplace 服务） |
|---|---|---|
| CTRL（对照） | `/v1/nonexistent-probe` | 404 `Cannot GET`（Express 路由不存在标准形） |
| E1 GetPlan | `GET /v1/entitlement/plan` | **404**（路由未注册） |
| E2 GetCatalog | `GET /v1/entitlement/catalog` | **404** |
| E3 GetQuota | `GET /v1/entitlement/quota` | **404** |
| E4 GetUsage | `GET /v1/entitlement/usage` | **404** |
| E5 Capabilities | `GET /v1/entitlement/capabilities` | **404** |
| E6 ActivateFreeQuota | `POST /v1/entitlement/free-quota/activate` | **404** |
| L1 Chat | `POST /v1/chat/completions` | **404** |
| L2 Embed | `POST /v1/embeddings` | **404** |
| L3 Models | `GET /v1/models` | **404** |
| K1 IssueKey | `POST /v1/keys/issue` | **404** |
| K3 RevokeKey | `POST /v1/keys/revoke` | **404** |
| E7 LLMConfig（冻结面，仅登记） | `GET /v1/entitlement/llm-config/:orgId` | **500 Internal Server Error**（路由存在，handler 内部错误——与 404 形成鲜明对照） |

## 公网可达性实测

| 源 → 目标 | 结果 |
|---|---|
| 122 宿主容器 → `http://122.51.51.177:4001` | **Connection timed out**（13 探针全超时） |
| 本机（开发机，真正外部源） → `http://122.51.51.177:4001/v1/models` 与 `/` | **HTTP 000，8s connect timeout** |

**2026-09-07 补充（Owner 确认）**：公网 4001 不通的直接原因是云服务器防火墙端口未开放。注意：M 侧 09-07 回函曾称"4001 公网已通（贵方 pull 在用）"，与该事实**矛盾**（我方 pull 实际走内网 172.17.0.14:4001，从不经公网）——差异已在 §9 G2 向 M 提出，由 M 澄清或开放防火墙。

## docker0 网段全扫描（09-07 追加，12:29-12:35 UTC）

方法：122 宿主容器对 docker0 bridge 网段（172.17.0.2-25）常用端口扫描 + 对开放端口逐个探 `/v1/entitlement/plan` 与 `/v1/models`。

| 地址 | 服务（响应签名） | 契约端点 |
|---|---|---|
| 172.17.0.14:4000 | Express 应用 | 404 |
| 172.17.0.14:4001 | **marketplace（已知）** | 404 |
| 172.17.0.14:5000 / 172.17.0.6:5000 | Docker Registry（registry/2.0） | — |
| 172.17.0.14:8000 / 8080 | Go 服务（text/plain 404） | 404 |
| 172.17.0.14:8888 | nginx 静态站（返回 HTML） | — |
| 172.17.0.3:8000 | **casdoor**（beego 身份服务，返回 HTML） | — |
| 172.17.0.3:3000 | Next.js 前端 | 404 |
| 172.17.0.6:4000 | Express 应用 | 404 |

**结论：docker0 网段全部存活 HTTP 服务已识别，无一注册契约端点（E1-E6/L1-L3/K1/K3）**。网关/计费服务要么部署在其它网段/主机（待 M 提供 G1 地址），要么尚未部署。

## 结论（可用性地图）

1. **M 侧 09-07 回函"沙箱 endpoint `http://122.51.51.177:4001/v1`（E1-E4 计量对账面已就绪）"不可验证**：
   - 该公网地址从外部（我方开发机）与 122 宿主自身**均不可达**（安全组/NAT 未生效或未开放）；
   - 唯一可达的 M 服务（内网 172.17.0.14:4001，即 marketplace）上 **E1-E6/L1-L3/K1/K3 全部 404 路由未注册**。
2. **网关计费面当前对外提供的真实能力 = 0 个端点**（12 个契约端点无一可用）。
3. **E7 已实现在 marketplace 服务上**（路由存在、500 内部错误）——与"E7 随 BYOK 冻结"口径并存（冻结=我方不接入，不代表 M 未实现）；500 详情（guard 前/后、缺表等）未知，仅登记。
4. 网关测试凭证（"加密渠道另发"）**至今未收到**——即使端点可达也无法完成鉴权冒烟。

## 我方侧就绪度（对照）

- GatewayClient 全部 12 端点实现 + fail-fast 装配 + E4 增量游标对齐（ac4633110，09-07 landed）+ 假网关 E2E——**我方代码面就绪，等真实端点与凭证即可冒烟**。
- K 线未交付期间 CSI 业务链（商机→智能体→执行）的 LLM 调用无通道（runtime 核实结论 B，见会话记录）——K1 签发链是业务链关键路径。
