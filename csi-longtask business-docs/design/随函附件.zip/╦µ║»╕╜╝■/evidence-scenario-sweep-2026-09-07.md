# Evidence: M↔C 全联调面冒烟状态（2026-09-07 13:12-13:20 UTC）

> Owner 09-07 指令：发函前把 M↔C 所有集成场景一并冒烟，统一收集信息、统一回函。四块 sweep 全完成，此为汇总取证。

## 1. C→M 订单面出站（场景二~九，21 端点探针，c2m- 签名 + nonce）

目标：内网 `172.17.0.14:4001`（marketplace）。假 UUID（order=1111…/sub=6666…）。

| 端点 | 结果 | 判定 |
|---|---|---|
| S2a GET task 详情 | **200** 完整 task 对象 | 通 |
| S3 PATCH order（project_id 回填） | 404 `order not found` | 路由在（业务 404） |
| S37 GET order/status | 404 `order not found` | 路由在 |
| S11 POST employer-mentions | 404 `order not found` | 路由在 |
| S13 POST spec | 404 `order not found` | 路由在 |
| S14 POST deliverables | 404 `order not found` | 路由在 |
| S15 POST revision-negotiation/start | **201** negotiation 创建成功 | 通（⚠️ 见发现项） |
| S15 POST revision-negotiation/{id}/decide | **400 `decision must be A/B/C/D`** | **drift-D1** |
| S16 POST revision-requests/classify | 404 `spec change not found` | 路由在 |
| S16 POST spec-changes | 404 `order not found` | 路由在 |
| S16 POST spec-changes/{id}/confirm | 404 `spec change not found` | 路由在 |
| S25 POST cancel-requests/respond | **400 `response must be accept/reject/counter_proposal`** | **drift-D2** |
| S26 POST cancel-requests/auto-resolve | **400 `outcome must be accept_partial_settlement/reject_cancel`** | **drift-D3** |
| S29 POST cancel-requests/finalize | 404 `cancel request not found` | 路由在 |
| S30 POST cancel-requests/to-dispute | 404 `cancel request not found` | 路由在 |
| S31 POST settlement/trigger | 404 `order not found` | 路由在 |
| S38 GET order/settlement | 404 `settlement not found` | 路由在 |
| S38 GET workspaces/{ws}/settlements | **200 `[]`** | 通 |
| S19 GET workspaces/{ws}/orders | **200 `[]`** | 通 |
| S40 POST disputes/evidence | 404 `dispute not found` | 路由在 |
| S43 POST disputes/acknowledge | 404 `dispute not found` | 路由在 |

**结论：M 侧订单面（场景二~九）约 21 端点全部已实现**（返结构化业务错误而非 Express 404 = 路由+业务校验全在）。与我方此前"20+ 项词表偏差"盘点互为印证，实测坐实 3 处请求键 drift：

| drift | M 实测要求 | 我方当前（契约 §） |
|---|---|---|
| D1 revneg decide 决策集 | `decision` ∈ **A/B/C/D** | `option` = append_revision/… 词表 |
| D2 cancel respond | `response` ∈ accept/reject/counter_proposal | `decision` |
| D3 cancel auto-resolve | `outcome` ∈ accept_partial_settlement/reject_cancel | `resolution` |

**发现项（M 侧观察，回函披露）**：S15 revneg-start 对**不存在的 order**（假 UUID 1111…）仍 **201 创建** negotiation（id `033b4135-b1a3-4ddc-9215-59db87ff17cf`）——疑似缺 order 存在性前置校验，请 M 侧确认是否有意为之（mock 口径）还是缺口。该残留记录请 M 侧清理或告知无需处理。

## 2. M→C 入站 webhook 承接面（我方 16 路由 × 22 event_type，自签冒烟）

目标：`csi-beta-api.cloud.hropenai.cn` 入站端点，m2c- 签名，信封 §8.3 完整形态（data 容器）。

- **16 条路由全部存活**（router.go L1490-1521 逐一注册，无 404）。
- **22 个 event_type 白名单注册全部正确命中**：错误 type 返 `VALIDATION_EVENT_TYPE_UNSUPPORTED`（白名单在正确拒绝），正确 type + 最小 body 进入字段校验层返 `VALIDATION_PAYLOAD_INVALID`——**路由+handler+信封 data 解析+type 白名单全链工作**。
- **settlement.completed / settlement.appeal_period_closed 两条 200 `{"accepted":true,"message":"processed"}`**（最小 body 恰好过校验，全链真通）。

注：早前一次自签用错 event_type 字符串（spec.confirmed vs spec.confirmed 等 22 个），本次已按 router.go 注册名修正后全命中。

**结论：我方 M→C 承接面 16 路由全就绪**。opportunity.pushed 已由 M 真实重推闭账（07:27 processed/200，evidence-m2c-closure）；其余事件类型最小冒烟全绿，等 M 真实场景推送时逐类走完整业务校验。

## 3. W1 partner API（M→我，自演 M 角色验证）

| 端点 | 结果 |
|---|---|
| GET /v1/partner/workspaces | **200**（beta-ac4-ws 全字段） |
| GET /v1/partner/workspaces/{id} | **200** |
| GET /v1/partner/orgs/{id}/workspaces | **200** `[]` |

M 可随时拉取（此前 M 自述 201 自验过，我方本轮独立复核三端点全通）。

## 4. 网关计费面（对照：见 evidence-gateway-probe-2026-09-07.md）

12 契约端点内网 4001 全 404（无服务），公网不可达，凭证未到——独立于本表，走 §9 G1-G7。

## 汇总（联调面状态总表）

| 面 | 方向 | 状态 |
|---|---|---|
| pull 商机投影（§9.2） | C→M | ✅ 已闭账（12:06 3 行投影） |
| submit_bid（§10.1） | C→M | ✅ wire 已实测可受理（F3/F5），金额口径 A 已确认 |
| 订单面场景二~九（~21 端点） | C→M | ✅ **M 全部已实现**；3 处请求键 drift 待对齐（D1-D3） |
| W2 workspace 生命周期推送 | C→M | ✅ 已过 M HMAC 门（F2） |
| M→C webhook 承接（16 路由） | M→C | ✅ 我方 16 路由全就绪 + opportunity.pushed 真实闭账 |
| W1 partner 档案 API | M→C | ✅ 三端点 200 |
| 网关计费面（E1-E6/L1-L3/K1/K3） | C→M | ❌ M 侧未部署/不可达（§9 G1-G7） |
| runtime LLM 执行链（K 线） | — | ❌ K 线未交付则业务链不可运行（§9 G7） |

**待对齐代码项（我方，非阻塞性——等真实订单数据后按 §7.1 与 M 确认词表再改）**：D1 revneg decide 决策集、D2 cancel respond 键、D3 cancel auto-resolve 键。均属 request 词表，已登记不阻塞真实场景跑通前的中段路径（M 对错误键返回 400 会显式暴露）。
